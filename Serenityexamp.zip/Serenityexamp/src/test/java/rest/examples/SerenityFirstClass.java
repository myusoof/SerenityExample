package rest.examples;

import net.serenitybdd.junit.runners.SerenityRunner;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(SerenityRunner.class)
public class SerenityFirstClass {

    @Test
    public void TestFirst(){

    }
}
