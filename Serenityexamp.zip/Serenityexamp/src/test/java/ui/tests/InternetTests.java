package ui.tests;

import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Steps;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;
import org.springframework.util.Assert;
import ui.pages.CurrentPage;
import ui.steps.InternetHerokuppSteps;

@RunWith(SerenityRunner.class)
public class InternetTests {

    @Steps
    InternetHerokuppSteps internetHerokuppSteps;

    @Steps
    CurrentPage currentPage;

    @Managed
    WebDriver browser;

    @Test
    public void launchInternetTest(){
        internetHerokuppSteps.isOnInternetHeroKuppPage();
        internetHerokuppSteps.clickOnLink("A/B Testing");
        Assert.isTrue(currentPage.getCurrentUrl().contains("abtest"),"testin");
    }

    @Test
    public void secondTest(){
        assert true;
    }
}
