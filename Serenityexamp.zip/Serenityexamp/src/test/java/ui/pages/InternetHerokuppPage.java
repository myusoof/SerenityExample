package ui.pages;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.DefaultUrl;
import org.openqa.selenium.WebElement;

@DefaultUrl("https://the-internet.herokuapp.com/")
public class InternetHerokuppPage extends PageObject {

    public WebElementFacade linkElement(String linkText) {
       return $(String.format("//a[contains(text(),'%s')]",linkText));
    }
}
