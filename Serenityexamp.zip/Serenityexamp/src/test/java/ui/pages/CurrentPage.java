package ui.pages;

import net.serenitybdd.core.pages.PageObject;

public class CurrentPage extends PageObject {

    public String getCurrentUrl(){
        return getDriver().getCurrentUrl();
    }
}
