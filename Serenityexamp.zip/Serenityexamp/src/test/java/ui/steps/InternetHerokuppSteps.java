package ui.steps;


import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Step;
import org.springframework.util.Assert;
import ui.pages.CurrentPage;
import ui.pages.InternetHerokuppPage;

public class InternetHerokuppSteps {

    InternetHerokuppPage internetHerokuppPage;
    CurrentPage currentPage;

    @Given("I would like to launch the test application")
    public void isOnInternetHeroKuppPage(){
        internetHerokuppPage.open();
    }

    @And("I click on (.*) link")
    public void clickOnLink(String link){
        internetHerokuppPage.linkElement(link).click();
    }

    @Then("^I validate whether I am in page$")
    public void i_validate_whether_I_am_in_page() {
    }

    @Then("^I validate whether I am on \"([^\"]*)\" page$")
    public void iValidateWhetherIAmOnPage(String link) throws Throwable {
        Assert.isTrue(currentPage.getCurrentUrl().contains(link),"true");
    }
}
