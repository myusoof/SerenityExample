"use strict";
exports.__esModule = true;
var protractor_1 = require("protractor");
var WebDriverHelper = /** @class */ (function () {
    function WebDriverHelper() {
    }
    WebDriverHelper.prototype.getDriver = function () {
        protractor_1.browser.driver;
    };
    return WebDriverHelper;
}());
exports.WebDriverHelper = WebDriverHelper;
