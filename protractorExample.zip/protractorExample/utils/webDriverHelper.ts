import { browser } from "protractor";


export default class WebDriverHelper{

    getDriver(): any{
        browser.driver    
    }
}