import { browser, element, by, By, $, $$, ExpectedConditions} from "protractor";


export class InternetHomePage{

    get(){
        browser.driver.get('https://the-internet.herokuapp.com/')

    }

    getTitle(): any {
        browser.driver.getTitle();
    }

    clickOnElementWithText(link: String): any{
        browser.driver.findElement(By.xpath( `//li/a[text()='${link}']`)).click();
       
    }
}