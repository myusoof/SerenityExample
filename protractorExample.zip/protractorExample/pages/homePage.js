"use strict";
exports.__esModule = true;
var protractor_1 = require("protractor");
var InternetHomePage = /** @class */ (function () {
    function InternetHomePage() {
    }
    InternetHomePage.prototype.get = function () {
        protractor_1.browser.driver.get('https://the-internet.herokuapp.com/');
    };
    InternetHomePage.prototype.getTitle = function () {
        protractor_1.browser.driver.getTitle();
    };
    InternetHomePage.prototype.clickOnElementWithText = function (link) {
        protractor_1.browser.driver.findElement(protractor_1.By.xpath("//li/a[text()='" + link + "']")).click();
    };
    return InternetHomePage;
}());
exports.InternetHomePage = InternetHomePage;
