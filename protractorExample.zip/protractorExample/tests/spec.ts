import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor'

import {InternetHomePage} from '../pages/homePage'

describe('Launch the internet applcation', function(){
  
  it('launch and click on the link',() =>{
      let internetHomePage = new InternetHomePage();
      internetHomePage.get();      
      internetHomePage.clickOnElementWithText('Checkboxes');
  });
});
