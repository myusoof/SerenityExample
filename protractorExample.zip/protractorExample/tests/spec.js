"use strict";
exports.__esModule = true;
var homePage_1 = require("../pages/homePage");
describe('Launch the internet applcation', function () {
    it('launch and click on the link', function () {
        var internetHomePage = new homePage_1.InternetHomePage();
        internetHomePage.get();
        internetHomePage.clickOnElementWithText('Checkboxes');
    });
});
