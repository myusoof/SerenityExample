const chai = require('chai')
const path = require('path')
const chaiAsPromised = require('chai-as-promised')
const Pact = require('@pact-foundation/pact').Pact
const { somethingLike: like, term } = require('@pact-foundation/pact').Matchers
const expect = chai.expect
const API_PORT = process.env.API_PORT || 9090
const { getLineSolutions } = require('../client')
var fs = require('fs')
chai.use(chaiAsPromised)

// Configure and import consumer API
// Note that we update the API endpoint to point at the Mock Service
const LOG_LEVEL = process.env.LOG_LEVEL || 'WARN'

const provider = new Pact({
  consumer: 'Line solution',
  provider: 'Line solution provider',
  port: API_PORT,
  log: path.resolve(process.cwd(), 'logs', 'pact.log'),
  dir: path.resolve(process.cwd(), 'pacts'),
  logLevel: LOG_LEVEL,
  spec: 2,
})

describe('Pact with Our line solutions', () => {
  before(() => {
    return provider.setup()
  })

  describe('given response is not null', () => {
    describe('when a call to the line solutions is made', () => {
        before(() => {
          return provider.addInteraction({
            state: 'get valid response',
            uponReceiving: 'a request for JSON data',
            withRequest: {
              method: 'GET',
              path: '/line_solutions/8f91d724-2002-46ec-9014-1c9b10f1038a/lines'
            },
            willRespondWith: {
              status: 200,
              headers: {
                'Content-Type': 'application/json; charset=utf-8',
              },  
            },
            body: {
              count: 1000,
              _links: {
                  self: {
                      href: "http://localhost:4545/line_solutions/8f91d724-2002-46ec-9014-1c9b10f1038a/lines?page=1&size=10000"
                  },
                  parent: {
                      href: "http://localhost:4545/line_solutions/8f91d724-2002-46ec-9014-1c9b10f1038a"
                  }
              },
              _embedded: {
                  lines: [
                      {
                          type: "HARD",
                          category: "PRIMARY",
                          _links: {
                              self: {
                                  href: "http://localhost:4545/line_solutions/8f91d724-2002-46ec-9014-1c9b10f1038a/lines/8ada00c4-b127-4151-8499-0edc2b9a62ba"
                              },
                              parent: {
                                  href: "http://localhost:4545/line_solutions/8f91d724-2002-46ec-9014-1c9b10f1038a/lines{?page,size}",
                                  templated: true
                              }
                          },
                          _embedded: {
                              pairing_instances: [
                                  {
                                      name: "DABH",
                                      length: 3,
                                      date: "2018-07-07",
                                      _links: {
                                          self: {
                                              href: "http://www.test.com"
                                          }
                                      }
                                  },
                                  {
                                      name: "DAXO",
                                      length: 3,
                                      date: "2018-07-26",
                                      _links: {
                                          self: {
                                              href: "http://www.test.com"
                                          }
                                      }
                                  },
                                  {
                                      name: "DA1Z",
                                      length: 3,
                                      date: "2018-07-01",
                                      _links: {
                                          self: {
                                              href: "http://www.test.com"
                                          }
                                      }
                                  },
                                  {
                                      name: "DAN6",
                                      length: 4,
                                      date: "2018-07-15",
                                      _links: {
                                          self: {
                                              href: "http://www.test.com"
                                          }
                                      }
                                  },
                                  {
                                      name: "DY18",
                                      length: 2,
                                      date: "2018-07-12",
                                      _links: {
                                          self: {
                                              href: "http://www.test.com"
                                          }
                                      }
                                  }
                              ]
                          },
                          line_number: 1,
                          am_pm: "AM",
                          block_time: 4775,
                          trip_for_pay: 92.8,
                          seat_position: "NONE"
                      }
                  ]
              }
            }
        })
        })

        it('can process the JSON payload from the provider', done => {
          const response1= getLineSolutions().then(
            response => {
              console.log(response)
            },
            error => {
              console.error(error)
            }
          )
          
          console.log("yusoof: " + response1.body)
          expect(response1.body).to.eventually.have.property('count', 1000).notify(done)
        })

        it('should validate the interactions and create a contract', () => {
          return provider.verify()
        })
    })
  })
  // Write pact files to file
  after(() => {
    return provider.finalize()
  })
})
