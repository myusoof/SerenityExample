const request = require('superagent')
const API_HOST = process.env.API_HOST || 'http://localhost'
const API_PORT = process.env.API_PORT || 9123
const moment = require('moment')
const API_ENDPOINT = `${API_HOST}:${API_PORT}`

// Fetch provider data
const getLineSolutions = () => {
  return request
    .get(`${API_ENDPOINT}/line_solutions/8f91d724-2002-46ec-9014-1c9b10f1038a/lines`)
    .then(
      res => {
        console.log(":::::"+API_ENDPOINT)
        return JSON.stringify(res.body)
        // if (JSON.stringify(res.body)) {
        //   return res.body
        // } else {
        //   throw new Error('Invalid line solution response')
        // }
      },
      err => {
        throw new Error(`Error from response: ${err.body}`)
      }
    )
}

module.exports = {
  getLineSolutions,
}