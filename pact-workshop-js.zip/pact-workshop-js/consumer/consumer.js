const client = require('./client')

client.getLineSolutions().then(
  response => {
    console.log(response)
  },
  error => {
    console.error(error)
  }
)
